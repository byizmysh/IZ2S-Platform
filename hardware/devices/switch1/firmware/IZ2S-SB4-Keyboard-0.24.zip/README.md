# IZ2S SB4 Keyboard 0.24 — IZ2S Platform

Switch 1 is the USB keyboard for SmileBASIC 4 on Switch 2:

`IZ2S Platform PC → Wi-Fi → Switch 1 → USB data cable → Switch 2 dock`

In **Connection**, select **Switch 1** in the input-device card. The device
settings open there, beside the normal First Setup and Launch workflow.

1. Connect Switch 1 to the PC, open DBI MTP Responder and choose **Copy via DBI**.
   Alternatively choose **Download SD package** in Connection and extract it
   to the SD root. Both install the NRO and its `connection.cfg` in
   `switch/iz2skeyboard/`. IZ2S Platform saves pairing automatically.
2. Exit DBI. Hold R while starting a game to open hbmenu in full application
   mode, then start IZ2S SB4 Keyboard. Album/applet mode is unsupported.
3. Connect Switch 1 to the same local network as the PC. Enter its displayed
   IPv4 address in Connection → Switch 1 and choose **Save and check**.
   No code is displayed or entered. Pairing survives restarts. TCP port: 24872.
4. Connect Switch 1's own USB-C port to a USB-A port on the Switch 2 dock using
   a data cable. Leave the app open and wait for **Keyboard ready**.
5. Set the Switch 2 USB keyboard layout to English (US). Use the usual SB4
   **First Setup** or **Launch** controls. Nothing is installed on Switch 2.

The transport executes the engine's normal keyboard plans: source insertion,
Shift+Home/Delete auto-indent cleanup, Escape/Enter timing, function keys and
fresh launch commands. Caps Lock follows the USB host's LED reports. Controller
plans (including Civ7 automatic chat) are rejected before any input is sent.

Every report waits for USB acknowledgement. Failed connections stop input;
partially completed jobs are never replayed automatically. The PC records job
IDs in `data/state/switch-input-jobs`. Use Stop in IZ2S Platform or B on Switch 1 to
disconnect/release keys. A opens a confirmed SB4 typing test; X opens the setup
guide; + exits. The graphical interface is English only, with touchscreen and
Joy-Con controls. The PC must stay connected during IZ2S Platform input.
The private key authorizes commands; this local TCP protocol is not encrypted.
The PC keeps it in `data/state/switch-keyboard/connection.cfg`. Public distribution
archives contain no keys; Connection prepares a private SD ZIP for this PC.
A standalone public NRO requires installation through Connection before Wi-Fi
control works. The app shows instructions if its configuration is missing.


Version 0.24. USB backend: NXHID (MIT); libnx: ISC; font: DejaVu.
See the bundled licenses and UPSTREAM.json.
