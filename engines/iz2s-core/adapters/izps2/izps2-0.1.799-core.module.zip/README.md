# IZPS2 emulator 0.1.799-hen.7

Local integration build for IZlauncher with SB4 HostedPosix. It uses the graphics and application data from IZPS2 0.1.799 with the supplied libsb4 engine. It uses the module’s existing BIOS and games folders. Console compatibility and performance are pending hardware verification.
