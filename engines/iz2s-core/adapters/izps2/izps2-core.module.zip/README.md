# IZPS2 emulator 0.1.767-hen.3

Local integration build for IZlauncher with SB4 HostedPosix. It uses the IZPS2 menu and graphics from 0.1.767 with the standalone ARMSX2 engine adapted to libsb4. For console testing, provide BIOS and media in the module’s bios and games folders.
